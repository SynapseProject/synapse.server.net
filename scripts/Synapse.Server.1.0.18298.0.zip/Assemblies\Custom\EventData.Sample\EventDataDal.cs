using System;
using System.Collections.Generic;

using LiteDB;

using Synapse.Core.Utilities;

namespace Synapse.Custom
{
    public class EventDataDal
    {
        private static string _db = @"EventData.db";
        private const string __table = "EventDataList";

        public EventDataDal() { }
        public EventDataDal(object rawConfig)
        {
            if( rawConfig == null )
                throw new ArgumentNullException( "rawConfig" );

            _db = DatabaseConnectionConfig.FromObject( rawConfig ).ConnectionString;
        }


        public EventData SelectSingle(long id)
        {
            using( var db = new LiteDatabase( _db ) )
            {
                var list = db.GetCollection<EventData>( __table );
                list.EnsureIndex( x => x.Id );

                return list.FindOne( x => x.Id == id ); ;
            }
        }

        public IEnumerable<EventData> SelectAll()
        {
            using( var db = new LiteDatabase( _db ) )
            {
                var list = db.GetCollection<EventData>( __table );
                return list.FindAll();
            }
        }

        public bool UpsertSingle(EventData item)
        {
            using( var db = new LiteDatabase( _db ) )
            {
                var list = db.GetCollection<EventData>( __table );
                return list.Upsert( item );
            }
        }

        public int UpsertList(List<EventData> items)
        {
            using( var db = new LiteDatabase( _db ) )
            {
                var list = db.GetCollection<EventData>( __table );
                return list.Upsert( items );
            }
        }

        public int Delete(long id)
        {
            using( var db = new LiteDatabase( _db ) )
            {
                var list = db.GetCollection<EventData>( __table );
                return list.Delete( x => x.Id == id ); ;
            }
        }
    }

    public class DatabaseConnectionConfig
    {
        public string ConnectionString { get; set; }

        public static DatabaseConnectionConfig FromObject(object rawConfig)
        {
            string config = YamlHelpers.Serialize( rawConfig );
            return YamlHelpers.Deserialize<DatabaseConnectionConfig>( config );
        }
    }
}