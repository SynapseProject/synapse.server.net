$events = Get-Eventlog -LogName System -Newest 1000
$json = ConvertTo-Json -InputObject $events
#$data = $events | Group-Object -Property source -noelement | Sort-Object -Property count -Descending
#$data


Invoke-RestMethod -Uri "http://localhost:20000/machine/events" -body: $json  -Method Post -ContentType: "application/json" -UseDefaultCredentials 
