# These are the sample RBAC Security implementation files.  Create a new Security.splx file or edit these freely.
#  - The filename **must** be Security.splx, and located at the path specified in the Controller->FileSystemDal config.
#  - Note: The top node of the tree **must** be SynapseRoot.
#  - Details availble here: http://synapse.readthedocs.io/en/latest/run/setup/rbac/

# Files:
#  - "_Empty" is a base setup, appropriate for starting "fresh."
#  - "_Example" shows more users/groups with a small container hierarchy.
#  - "_Samples" corresponds to the sample Plans shipped with the release distribution.