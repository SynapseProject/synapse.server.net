﻿using System;
using System.Collections.Generic;

using Newtonsoft.Json;

namespace Synapse.Custom
{
    public partial class EventData
    {
        public int Id { get { return Index; } set { Index = value; } }

        [JsonProperty( "MachineName", NullValueHandling = NullValueHandling.Ignore )]
        public string MachineName { get; set; }

        [JsonProperty( "Data", NullValueHandling = NullValueHandling.Ignore )]
        public List<object> Data { get; set; }

        public int Index { get; set; }

        [JsonProperty( "Category", NullValueHandling = NullValueHandling.Ignore )]
        public string Category { get; set; }

        [JsonProperty( "CategoryNumber", NullValueHandling = NullValueHandling.Ignore )]
        public long? CategoryNumber { get; set; }

        [JsonProperty( "EventID", NullValueHandling = NullValueHandling.Ignore )]
        public long? EventId { get; set; }

        [JsonProperty( "EntryType", NullValueHandling = NullValueHandling.Ignore )]
        public long? EntryType { get; set; }

        [JsonProperty( "Message", NullValueHandling = NullValueHandling.Ignore )]
        public string Message { get; set; }

        [JsonProperty( "Source", NullValueHandling = NullValueHandling.Ignore )]
        public string Source { get; set; }

        [JsonProperty( "ReplacementStrings", NullValueHandling = NullValueHandling.Ignore )]
        public List<string> ReplacementStrings { get; set; }

        [JsonProperty( "InstanceId", NullValueHandling = NullValueHandling.Ignore )]
        public long? InstanceId { get; set; }

        [JsonProperty( "TimeGenerated", NullValueHandling = NullValueHandling.Ignore )]
        public string TimeGenerated { get; set; }

        [JsonProperty( "TimeWritten", NullValueHandling = NullValueHandling.Ignore )]
        public string TimeWritten { get; set; }

        [JsonProperty( "UserName", NullValueHandling = NullValueHandling.Ignore )]
        public string UserName { get; set; }

        [JsonProperty( "Site" )]
        public object Site { get; set; }

        [JsonProperty( "Container" )]
        public object Container { get; set; }
    }
}