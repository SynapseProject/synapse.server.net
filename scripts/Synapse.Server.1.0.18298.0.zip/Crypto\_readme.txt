# The keyContainerName for the sample files is "sample".

# There's nothing special about the filename or extensions - .pubOnly/.pubPriv are just the default extensions for "public key only" and "public and private key", respectively.