# These are the sample Plans/scripts that ship with Synapse.Server.
# You may delete/modify the '.\_Samples' folder and .\Dal\Plans\sample*.yaml content freely.

# Example URL for executing the "sampleHtml" Plan and returning an HTML result to the browser.
http://localhost:20000/synapse/execute/samplehtml/start/sync/?serializationType=html